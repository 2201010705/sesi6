<?php
//konfigurasi database
    define("DBHOST","localhost");
    define("DBUSER","root");
    define("DBPASS","");
    define("DBPORT","3306");
    define("DBNAME","dbmahasiswa");

//konfigurasi timezone
//jika menggunakan localhost maka waktu mengikutin tempat localhost berada
date_default_timezone_set('Asia/Makassar');
    



