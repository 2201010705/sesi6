<!DOCTYPE html>
<html>
<head>
	<title>Login Form</title>
</head>
<body>
	<form action="login.php" method="post">
		<label for="username">Username:</label>
		<input type="text" id="username" name="username"><br><br>
		<label for="password">Password:</label>
		<input type="password" id="password" name="password"><br><br>
		<input type="submit" value="Submit">
	</form>
	<form action="login2.php" method="post">
		<label for="username2">Username:</label>
		<input type="text" id="username2" name="username2"><br><br>
		<label for="password2">Password:</label>
		<input type="password" id="password2" name="password2"><br><br>
		<input type="submit" value="Submit">
	</form>
</body>
</html>

